---
name: investigative-tech-scout
description: Melakukan riset jurnalistik mendalam, verifikasi fakta silang (cross-check) minimal 2-3 media besar (Kompas, Detik, Antara, Reuters, The Verge, Bloomberg), memisahkan fakta vs rumor, dan mengekstrak rujukan link berita asli. Gunakan saat agent bertugas menyusun berita, investigasi tren teknologi, cek fakta regulasi, atau liputan mendalam agar akurat dan bebas halusinasi.
license: MIT
metadata:
  author: DaeReview Editorial Desk
  version: "1.0.0"
  category: journalism
inputs:
  - name: topic
    description: Topik berita atau isu teknologi yang akan diriset
    required: true
  - name: source_url
    description: URL rujukan awal dari pengguna (opsional)
    required: false
---

# Investigative Tech Scout (Riset Berita & Verifikasi Silang)

Gunakan skill ini untuk memandu agen dalam melakukan riset berita teknologi berstandar jurnalisme investigatif kelas dunia (Swiss Editorial Standard).

## Prinsip Kerja Utama:
1. **Verifikasi Silang (Rule of Three):**
   - Jangan pernah menyimpulkan satu kejadian hanya dari satu kutipan/sumber acak.
   - Bandingkan minimal 2 sampai 3 publikasi kredibel (misalnya: Kompas Tekno, Detik, Antara, Reuters, Bloomberg, The Verge).
2. **Pemisahan Kategori Informasi:**
   - **FAKTA RESMI:** Pernyataan resmi pejabat/korporasi, tanggal rilis terkonfirmasi, data regulasi hukum/TKDN.
   - **RUMOR / BOCORAN:** Klaim tipster/leaker (harus ditandai sebagai rumor, bukan fakta mutlak).
   - **ANALISIS / OPINI:** Pandangan pengamat atau implikasi terhadap konsumen.
3. **Ekstraksi Atribusi & Link Sumber (WAJIB):**
   - Catat nama media publikasi dan URL asli dari berita yang ditemukan.
   - Setiap poin data penting (angka, tanggal, sanksi, kutipan) harus memiliki pemilik atribusi yang jelas.

## Format Struktur Keluaran Riset:
```markdown
### 1. KRONOLOGI & FAKTA INTI (5W + 1H)
- Apa peristiwa persisnya:
- Kapan & di mana diumumkan:
- Siapa pihak terkait / pejabat yang berbicara:
- Mengapa isu ini terjadi sekarang:
- Dampak langsung bagi konsumen di Indonesia:

### 2. KUTIPAN PERNYATAAN RESMI
- "[Isi kutipan resmi]" — Nama Pejabat / Pihak Resmi (Media Sumber)

### 3. RUJUKAN SUMBER MEDIA ASLI
- [Nama Media / Judul Berita](URL Sumber): Poin data yang dikonfirmasi
```
