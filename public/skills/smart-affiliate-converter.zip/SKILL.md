---
name: smart-affiliate-converter
description: Mengoptimasi rekomendasi belanja e-commerce (Shopee & Tokopedia) dengan pendekatan konsultatif tanpa hard-selling. Memberikan panduan pemilihan varian produk terbaik (value-for-money ratio), momentum diskon terbaik, dan penempatan call-to-action (CTA) yang natural dan berkonversi tinggi. Gunakan saat menyusun rekomendasi pembelian produk dan tabel harga.
license: MIT
metadata:
  author: DaeReview Affiliate Desk
  version: "1.0.0"
  category: monetization
inputs:
  - name: product_name
    description: Nama produk yang akan diberikan rekomendasi pembelian
    required: true
  - name: variants
    description: Pilihan kapasitas memori / varian produk (opsional)
    required: false
---

# Smart Affiliate Converter (Strategi Konversi Belanja Cerdas)

Skill ini memposisikan agen sebagai konsultan belanja pribadi pembaca (*Personal Tech Shopper*). Tujuannya adalah membantu pembaca berhemat sekaligus memaksimalkan konversi tautan resmi marketplace.

## Prinsip Rekomendasi Varian:
1. **Analisis Selisih Harga (Delta Price Analysis):**
   - Jika selisih varian dasar ke varian atas kurang dari 15% harga total, rekomendasikan varian atas (misal: "Selisih RAM 8GB ke 16GB hanya Rp 200.000, jauh lebih awet untuk 3 tahun ke depan").
   - Jika varian tertinggi harganya melambung tidak wajar, ingatkan pembaca untuk mengambil varian tengah (Sweet Spot).
2. **Kapan Waktu Terbaik Membeli:**
   - Informasikan momen potongan harga resmi (Flash Sale bulanan, promo tanggal kembar 10.10/11.11/12.12, atau Payday Promo).
3. **Penyusunan Call-To-Action (CTA) Alami:**
   - Hindari kata memaksa: "Beli sekarang juga!", "Klik link ini!".
   - Gunakan pendekatan informasi nilai:
     * *"Cek harga diskon toko official terverifikasi hari ini di Shopee"*
     * *"Bandingkan ketersediaan stok garansi resmi di Tokopedia"*
