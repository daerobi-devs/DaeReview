---
name: google-discover-hookmaster
description: Merancang judul berita/review dengan CTR tinggi dan menulis lead paragraf pertama yang memikat tanpa gaya klise AI. Mengharamkan kata pembuka generik, menciptakan curiosity gap yang etis, serta memaksimalkan dwell time pembaca untuk dominasi Google Discover dan ranking SEO. Gunakan saat memformulasikan judul artikel, editorial hook, dan ringkasan meta.
license: MIT
metadata:
  author: DaeReview Editorial Desk
  version: "1.0.0"
  category: copywriting-seo
inputs:
  - name: topic_or_draft
    description: Draf judul atau topik mentah yang akan dioptimasi
    required: true
---

# Google Discover Hookmaster (Anti-Klise & High-CTR Copywriting)

Skill ini bertugas membunuh gaya penulisan AI yang membosankan dan menggantinya dengan gaya jurnalisme modern yang tajam, memikat, dan disukai algoritma Google Discover.

## Daftar Kata Terlarang (Blacklist AI Tropes):
❌ DILARANG KERAS: "Di era digital yang berkembang pesat saat ini..."
❌ DILARANG KERAS: "Tak dapat dipungkiri bahwa..."
❌ DILARANG KERAS: "Mari kita simak ulasan mendalam berikut ini..."
❌ DILARANG KERAS: "Sebagai kesimpulan, produk ini layak dipertimbangkan..."
❌ DILARANG KERAS: Menggunakan frasa pembuka bertele-tele tanpa substansi.

## Formula Judul Bernilai Klik Tinggi (High-CTR):
1. **Pola Konflik / Realita:**
   - *"Janji Manis Brosur [Produk] vs Realita Setelah 14 Hari Pemakaian"*
2. **Pola Regulasi & Kebijakan Nyata:**
   - *"Dampak Larangan [Isu]: Konsumen Indonesia Wajib Tahu Hal Ini Sebelum Beli"*
3. **Pola Uji Komparasi Tajam:**
   - *"Selisih Rp 300 Ribu: Alasan Mengapa Kamu Sebaiknya Skip [Opsi A] dan Pilih [Opsi B]"*

## Formula Lead Paragraf Pertama (The 3-Second Hook):
- **Kalimat 1:** Langsung menusuk ke inti fakta atau kontroversi paling mengejutkan.
- **Kalimat 2:** Menjelaskan mengapa hal ini berdampak langsung ke dompet atau kenyamanan pembaca.
- **Kalimat 3:** Menjanjikan jawaban atau investigasi yang tidak akan ditemukan di media lain.
